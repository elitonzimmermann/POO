package com.eliton.interface.calendario;

import com.eliton.interface.display.formatter;
import com.eliton.interface.radioFm.String;
import com.eliton.interface.display.T;

public class calendarioFormatter implements formatter {

	public String formatter(calend value) {
		return null;
	}


	/**
	 * @see com.eliton.interface.display.formatter#formatter(com.eliton.interface.display.T)
	 * 
	 *  
	 */
	public void formatter(T value) {

	}

}
