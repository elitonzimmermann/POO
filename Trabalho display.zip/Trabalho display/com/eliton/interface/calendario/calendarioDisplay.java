package com.eliton.interface.calendario;

import com.eliton.interface.display.display;

public class calendarioDisplay extends display {

	private int dia;

	private int mes;

	private int ano;

	public void show() {

	}

	public int getDia() {
		return 0;
	}

	public setDia(int dia) {

	}

	public int getMes() {
		return 0;
	}

	public void getMes(int mes) {

	}

	public int getAno() {
		return 0;
	}

	public void setAno(int ano) {

	}

}
