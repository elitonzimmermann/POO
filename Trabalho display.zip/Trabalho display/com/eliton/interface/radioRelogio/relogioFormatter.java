package com.eliton.interface.radioRelogio;

import com.eliton.interface.display.formatter;
import com.eliton.interface.radioFm.String;
import com.eliton.interface.display.T;

public class relogioFormatter implements formatter {

	public String formatter(relogio value) {
		return null;
	}


	/**
	 * @see com.eliton.interface.display.formatter#formatter(com.eliton.interface.display.T)
	 * 
	 *  
	 */
	public void formatter(T value) {

	}

}
