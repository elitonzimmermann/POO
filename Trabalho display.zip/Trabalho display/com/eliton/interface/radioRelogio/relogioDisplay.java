package com.eliton.interface.radioRelogio;

import com.eliton.interface.display.display;

public class relogioDisplay extends display {

	private int hora;

	private int minuto;

	public void show() {

	}

	public int getHora() {
		return 0;
	}

	public setHora(int hora) {

	}

	public int getMinuto() {
		return 0;
	}

	public void setMinuto(int minuto) {

	}

}
