package com.eliton.interface.display;

public interface formatter {

	public void formatter(T value);

}
