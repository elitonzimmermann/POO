package com.eliton.interface.display;

public class display {

	private void show ();

}
