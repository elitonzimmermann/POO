package com.eliton.interface.radioFm;

import com.eliton.interface.display.display;

public class fmDisplay extends display {

	private double estacao;

	public void show() {

	}

	public double gesEstacao() {
		return 0;
	}

	public gesEstacao(double estacao) {

	}

}
