package com.eliton.interface.temperatura;

public class temp {

}
