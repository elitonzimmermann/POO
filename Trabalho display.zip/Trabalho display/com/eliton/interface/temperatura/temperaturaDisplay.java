package com.eliton.interface.temperatura;

import com.eliton.interface.display.display;

public class temperaturaDisplay extends display {

	private double temp;

	public void show() {

	}

	public double getTemperatura() {
		return 0;
	}

	public setTemperatura(double temperatura) {

	}

}
