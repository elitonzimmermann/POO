public class conta {

	private int nome;

	private int nascimento;

	private int sexo;

	private int email;

	private int senha;

}
