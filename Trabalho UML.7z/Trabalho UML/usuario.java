public class usuario extends feed {

	public float publicar() {
		return 0;
	}

	public float editar() {
		return 0;
	}

	public float excluir() {
		return 0;
	}

	public String comentar() {
		return null;
	}

	public float curtir() {
		return 0;
	}

	public float retweetar() {
		return 0;
	}

	public boolean pesquisarUsuarios() {
		return false;
	}

	public boolean seguirUsuario() {
		return false;
	}

}
