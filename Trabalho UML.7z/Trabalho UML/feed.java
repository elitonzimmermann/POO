public class feed extends tweet {

	private String nomeUsuario;

	private int data;

	public char textos() {
		return 0;
	}

	public float imagem() {
		return 0;
	}

	public float video() {
		return 0;
	}

	public float retweets() {
		return 0;
	}

}
