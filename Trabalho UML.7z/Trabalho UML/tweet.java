public class tweet extends video {

	private char texto;

	private char imagem;

	private int video;

	private int data;

	private float retweetar;

}
