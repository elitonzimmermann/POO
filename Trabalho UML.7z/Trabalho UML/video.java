public class video {

	private float duracao;

}
