import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class TarefaDAO extends BasicoDAO{
	
	public void insert(Tarefa Tarefa) {

		String sql = " insert into Tarefa(nome, status) values(?,?)";
		try {
			
			// try with-resources
			
			try (Connection conn = getConnection();
				 PreparedStatement statement = conn.prepareStatement(sql)){
				
				statement.setString(1, Tarefa.getNome());
				statement.setString(2, Tarefa.getStatus());
				statement.execute();
			}
		}catch (Exception e){
			e.printStackTrace();
		}
		
	}

	public void delete(int id) {
		
		String sql = "delete from Tarefa where id = ?";
		
		try(Connection conn = getConnection();
			PreparedStatement statement = conn.prepareStatement(sql)) {
			statement.setInt(1, id);
			statement.execute();
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	public void update(Tarefa Tarefa) {
		String sql = " update Tarefa set nome = ?, status = ? where id = ?";
		
		try (Connection conn = getConnection();
			 PreparedStatement statement = conn.prepareStatement(sql)){
			statement.setString(1, Tarefa.getNome());
			statement.setString(2, Tarefa.getStatus());
			statement.setInt(3, Tarefa.getId());
			statement.execute();
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	public List<Tarefa> getAll(){
		List<Tarefa> list = new ArrayList<>();
		String sql = " select id, nome, status from Tarefa order by nome";
		
		try(Connection conn = getConnection();
			PreparedStatement statement = conn.prepareStatement(sql)) {
			ResultSet resultSet = statement.executeQuery();
			while(resultSet.next()) {
				Tarefa Tarefa = new Tarefa(resultSet.getInt(1), resultSet.getString(2), resultSet.getString(3));
				list.add(Tarefa);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	
}
