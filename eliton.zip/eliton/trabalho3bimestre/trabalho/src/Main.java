public class Main {

	public static void main(String[] args) {
		TarefaDAO dao = new TarefaDAO();
		
		Tarefa tare1 = new Tarefa("Tarefa 1", "h� fazer");
		dao.insert(tare1);
		Tarefa tare2 = new Tarefa("Tarefa 2", "feito");
		dao.insert(tare2);
		for(Tarefa tarefa : dao.getAll()) {
			System.out.println(tarefa);
		}
		
		Tarefa tareupd = new Tarefa("Tarefa 1 agora � 2", "finalizado");
		dao.update(tareupd);
		for(Tarefa tarefa : dao.getAll()) {
			System.out.println(tarefa);
		}
		
		int idparadeletar =1;
		dao.delete(idparadeletar);
		for(Tarefa tarefa : dao.getAll()) {
			System.out.println(tarefa);
		}
		
		
	}

}
